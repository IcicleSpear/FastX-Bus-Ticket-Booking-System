package com.hexaware.fastx.exception;

public class AmenityNotFoundException extends RuntimeException {
    public AmenityNotFoundException(String message) {
        super(message);
    }
}
