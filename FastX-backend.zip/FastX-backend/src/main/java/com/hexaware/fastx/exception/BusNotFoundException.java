package com.hexaware.fastx.exception;

public class BusNotFoundException extends RuntimeException {
    public BusNotFoundException(String msg) { super(msg); }
}
