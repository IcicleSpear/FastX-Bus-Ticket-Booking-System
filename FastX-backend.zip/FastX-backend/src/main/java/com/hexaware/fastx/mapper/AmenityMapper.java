package com.hexaware.fastx.mapper;

public class AmenityMapper {

}
