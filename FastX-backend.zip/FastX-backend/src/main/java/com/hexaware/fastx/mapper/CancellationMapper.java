package com.hexaware.fastx.mapper;

public class CancellationMapper {

}
